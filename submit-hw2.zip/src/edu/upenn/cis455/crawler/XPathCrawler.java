package edu.upenn.cis455.crawler;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

import javax.net.ssl.HttpsURLConnection;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.tidy.Tidy;

//import org.apache.commons.io.IOUtils;






import sun.net.util.URLUtil;
import edu.upenn.cis455.crawler.info.URLInfo;
import edu.upenn.cis455.storage.DBWrapper;


public class XPathCrawler {
	
	private String dataURL;
	private int maxSize;
	private boolean fourthArg = false;
	private static int numFiles = -1;
	private static LinkedList<String> urlList = new LinkedList<String>();
	public boolean isHttps = false;
	private int filesCrawled;
	private URLInfo urlObj;
	
	public static void main(String args[]){
		XPathCrawlerFactory fact = new XPathCrawlerFactory();
		XPathCrawler crawl = fact.getCrawler();
		crawl.addToLinks(args[0]);
		crawl.setDataUrl(args[1]);
		crawl.setMaxSize(Integer.parseInt(args[2]));
		if(!args[3].equals("") && args[3]!=null){
			crawl.setNumFiles(Integer.parseInt(args[4]));
		}
	}
//set methods
	public void setStartUrl(String start){
		addToLinks(start);
	}
	public void setDataUrl(String data){
		File file = new File(data);
		if(!file.exists())
			file.mkdirs();
		dataURL = data;
		
		DBWrapper.init(data);
	}
	public void setMaxSize(int size){
		maxSize= size;
	}
	public void setNumFiles(int num){
		fourthArg = true;
		numFiles = num;
	}
	
// crawl
	public void crawl() throws UnknownHostException, DOMException, IOException, ParseException{
		while(!urlList.isEmpty()){
		String next=urlList.getLast();
		urlList.removeLast();
			parse(next);
		}
	}
	
// parse
	public void parse(String url) throws UnknownHostException, IOException, DOMException, ParseException{
		if((!fourthArg)||(filesCrawled<numFiles&&fourthArg)){
		if(checkHost(url)==true){
		saveDoc(url);
		OutputStream os;
		InputStream is;
		HttpsURLConnection tempCon = null;
		Socket socket = null;
		if(url.startsWith("https://")){
			URL temp = new URL(url);
			tempCon = (HttpsURLConnection)temp.openConnection();
			tempCon.setDoOutput(true);
			os = tempCon.getOutputStream();
			is = tempCon.getInputStream();
		}
		else{
			//set socket
			socket = new Socket(urlObj.getHostName(), urlObj.getPortNo());
			//In/Output Stream
			is = socket.getInputStream();
			os = socket.getOutputStream();
		}
		
		PrintWriter pw = new PrintWriter(os);
		
		
		//Write Http request
		pw.println("GET "+ urlObj.getFilePath() +" HTTP/1.1");
		pw.println("Host: "+ urlObj.getHostName());
		pw.println();
		pw.flush();
		
		//JTidy
		Tidy myTidy = new Tidy();
		myTidy.setXmlOut(true);
		Document doc =myTidy.parseDOM(is, null);
		NodeList links =doc.getElementsByTagName("a");
		
		//add links to list
		for(int i=0; i<links.getLength(); i++){
			String link =links.item(i).getAttributes().getNamedItem("href").getNodeValue();
			addToLinks(url);
			
		}
		tempCon.disconnect();
		socket.close();
	}}}
	

	
	//check if the host satisfys the conditions
	public boolean checkHost(String url) throws UnknownHostException, IOException, ParseException{
		
		OutputStream os;
		InputStream is;
		HttpsURLConnection tempCon =null;
		Socket socket = null;
		urlObj = new URLInfo(url);
		if(url.startsWith("https://")){
			isHttps=true;
			URL temp = new URL(url);
			tempCon = (HttpsURLConnection)temp.openConnection();
			tempCon.setRequestMethod("HEAD");
			tempCon.setDoOutput(true);
			os = tempCon.getOutputStream();
			is = tempCon.getInputStream();
		}
		else{
			isHttps=false;
			//set socket
			socket = new Socket(urlObj.getHostName(), urlObj.getPortNo());
			//In/Output Stream
			is = socket.getInputStream();
			os = socket.getOutputStream();
		}
				
		//Print Writet
		PrintWriter pw = new PrintWriter(os);
				
				
		//Write Http request
		pw.println("HEAD "+ urlObj.getFilePath() +" HTTP/1.1");
		pw.println("Host: "+ urlObj.getHostName());
		pw.println();
		pw.flush();
		if(isHttps){
			if(Integer.parseInt(tempCon.getHeaderField("Content-Length")) < (maxSize * 10 *10 *10* 10 *10 *10)){
				System.out.println();
				return false;
				}
			if(DBWrapper.getPageByURL(url)!=null){
				if(DBWrapper.getPageDate(url).getTime() > tempCon.getHeaderFieldDate("Last-Modified", (long) -1.0)){
					return false;
				}
			}
			if(tempCon.getHeaderField("Content-Type").equals("text/html")){
				return true;
			}
			else if(tempCon.getHeaderField("Content-Type").endsWith("xml")){
				saveDoc(url);
				return false;
			}
			
		}
		else{
			BufferedReader br = new BufferedReader(
				new InputStreamReader(is));
		String temp = "";
		while((temp=br.readLine())!=null){
			//date
			System.out.println(temp);
			if(temp.startsWith("Date: ")){
				String dhead = temp.split(": ")[1];
				//DateFormat df = new SimpleDateFormat() 
			}
			//content-type
			else if(temp.startsWith("Content-Type: ")){
				String chead = temp.split(": ")[1];
				if(chead.startsWith("text/html")){
					
				}
				else if(chead.endsWith("xml")){
					saveDoc(url);
					return false;
				}
				else{
					return false;
				}
			}
		}
		br.close();}//end else
		tempCon.disconnect();
		socket.close();
		return true;
	}
	
	//save Doc to db
	public void saveDoc(String url) throws IOException{
		//HttpsURLConnection tempCon;
		numFiles++;
		OutputStream os;
		InputStream is;
		Socket socket = null;
		HttpsURLConnection tempCon = null;
		
		
		if(url.startsWith("https://")){
			URL temp = new URL(url);
			tempCon = (HttpsURLConnection)temp.openConnection();
			tempCon.setDoOutput(true);
			os = tempCon.getOutputStream();
			is = tempCon.getInputStream();
		}
		else{
			//set socket
			socket = new Socket(urlObj.getHostName(), urlObj.getPortNo());
			//In/Output Stream
			is = socket.getInputStream();
			os = socket.getOutputStream();
		}
		//Write Http request
		PrintWriter pw = new PrintWriter(os);
		pw.println("GET "+ urlObj.getFilePath() +" HTTP/1.1");
		pw.println("Host: "+ urlObj.getHostName());
		pw.println();
		pw.flush();
		DataInputStream dIn = new DataInputStream(is);
		byte[] pass= new byte[is.available()];
		dIn.readFully(pass);
		socket.close();
		tempCon.disconnect();
		//tempCon.
	}
	public void addToLinks(String url){
		synchronized(urlList){
		urlList.addFirst(fixUrl(url));
		}
	}
	public String fixUrl(String url){
		String tempProt ="http://";
		if(isHttps){
			tempProt ="https://";
		}
		if(url.startsWith("/")){
			url = url+urlObj.getHostName();
		}
		if(url.startsWith(urlObj.getHostName())){
			url ="www."+ url;
		}
		if(url.startsWith("www.")){
			url = tempProt+url;
		}
		return url;
	}
	
}
